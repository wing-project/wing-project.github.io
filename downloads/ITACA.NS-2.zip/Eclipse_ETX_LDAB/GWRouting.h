/* -*- mode:c++ -*- ********************************************************
 * file:        GWRouting.h
 *
 * author:      Stefano Maurina
 *
 * copyright:   2008 University of Trento
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBGMA Routing Protocol
 * description: Header file for the GWRouting Simple Module
 *
 ***************************************************************************/


#ifndef GWROUTING_H
#define GWROUTING_H

#include <omnetpp.h>

#include "BasicLayer.h"
#include "SimpleAddress.h"
#include <vector>

#include "RANNPkt_m.h"
#include "RREPPkt_m.h"
#include "ApplPkt_m.h"
#include "NetwPkt_m.h"
#include "PROBEPkt_m.h"
#include "CHANGEPkt_m.h"
#include "GWREQPkt_m.h"
#include "GWREPPkt_m.h"

class GWRouting : public BasicLayer
{

protected:
	/** @brief cached variable of my MAC address */
	int myMACAddr;
  /** @brief cached variable of my networ address (not really used) */
  int myNetwAddr;
	/** @brief cached variable of the time the first RANN for a GW is sent */
	int delayrannbegin;
  /** @brief cached variable of the time between a RANN and the next */
	int delayrann;
  /** @brief cached variable of the lenght of a RANN packet */
	int rannheaderLength;
  /** @brief cached variable of the lenght of a Unicast packet */
	int netwheaderLength;
  /** @brief cached variable of the lenght of a MAC packet */
	int macheaderLength;
  /** @brief cached variable of the lenght of an application packet */
	int applheaderLength;
	/** @brief cached variable of the lenght of a CHANGE packet */
	int changeheaderLength;
	/** @brief cached variable of the value of the rate threshold */
	int ratethreshold;
  /** @brief sequence number of the RANN message */		
	unsigned int RANNSeqNumber;
  /** @brief cMessage pointer to be used as a self-message */
  cMessage *delayTimer;
  /** @brief cached variable of the number of Mesh Nodes */
	int numMNs;
	/** number of packets dropped */
	int numdropped;

	/** @brief vector which contains the arrival times of the network packets to a GW */
	typedef std::vector< double > Sample;
		
	Sample sample;
  /** @brief cMessage pointer to be used as a self-message */
  cMessage *rateCompute;

	/** @brief cached variable of the time the rate is computed */
	int delayrate;

	//ETX metric stuff
 	/** @brief cMessage pointer to be used as a self-message */
 	cMessage *etxTimer;
 	/** @brief cached variable of the time between a PROBE and the next */
	int delayetx;
 	/** @brief cached variable of the lenght of a PROBE packet */
	int etxheaderLength;



  /** @brief struct used to represent a Mesh Node Routing Entry */	
  struct MNRoutingEntry {
      int destMNMACAddr;
      int nextHopMacAddr;
			double ETX;
			simtime_t time; //NB: simtime_t is a typedef for a double
  };

  /** @brief list used as a MN Routing Table to keep the Mesh Node Routing Entry */	
  typedef std::list<MNRoutingEntry*> MNRoutingTable;

	//  declaration of Mesh Routing Table for the Gateway
	MNRoutingTable mnroutingtable;

  /** @brief find a MN in the MNRT based on its address */
  MNRoutingTable::iterator findMN(int id)  {
  MNRoutingTable::iterator it;
      for(it = mnroutingtable.begin(); it != mnroutingtable.end(); ++it) {
          if((*it)->destMNMACAddr == id) break;
      }
      return it;
  }
  
  /** @brief vector used to contain all the Mesh Node addresses;
      it is used for simulation purpose, to choose a destination MN to which send the flow among the available MN */	
	typedef std::vector<MNRoutingTable::iterator> Iterators;

	Iterators iterators;

public:
  Module_Class_Members( GWRouting, BasicLayer, 0 );

  /** @brief Initialization of the module and some variables*/
  virtual void initialize(int);
	virtual void finish();

  enum GWRouting_MSG_TYPES{
		SEND_RANN_TIMER,
		SEND_PROBE,
		RATE_COMPUTE
  };

protected:
  /** 
    * @name Handle Messages
    * @brief Functions to redefine by the programmer
    *
    * These are the functions provided to add own functionality to your
    * modules. These functions are called whenever a self message or a
    * data message from the upper or lower layer arrives respectively.
    *
    **/
   /*@{*/
    

    
  /** @brief Handle messages from lower layer */
  virtual void handleLowerMsg(cMessage* msg);     // received messages from the mac level

  /** @brief Handle self messages */ 
  virtual void handleSelfMsg(cMessage* msg);	

  /** @brief Handle control messages from lower layer */
	virtual void handleLowerControl(cMessage* msg);  // control messages from the mac layer

  /** @brief Handle messages from upper layer */
	virtual void handleUpperMsg(cMessage *msg);		// received messages from the appl. layer

  /** @brief Decapsulate a lower layer packet */
  virtual cMessage* decapsMsg(NetwPkt*);  	
    
  /** @brief Encapsulate higher layer packet */
  virtual NetwPkt* encapsMsg(ApplPkt * appl); 

  /** @brief send a broadcast packet to the neighbors */
  void sendRANN();

  /** @brief update the numer of messages dropped on the GUI */
	void updateDisplay();

	//ETX stuff 
	/** @brief send a probe broadcast packet to the neighbors */
  void sendPROBE();

	//LDAB stuff
	/** @brief send a CHANGE unicast packet to a Mesh Node */
	void sendCHANGE();
	void setSimTime(NetwPkt* pkt);
	/** @brief feed the vector to cumpute the incoming rate */
	void feedRATE();
	void sendGWREP(int);
	/** @brief compute the incoming rate analyzing the sample vector */
  double computeRATE();
	
};

#endif
