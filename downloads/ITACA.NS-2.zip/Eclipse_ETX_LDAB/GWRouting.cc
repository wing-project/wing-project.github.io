/***************************************************************************
 * file:        GWRouting.cc
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 
 *              
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA Routing Protocol
 * description: Routing layer of the Gateways
 *               
 ***************************************************************************/

#include "GWRouting.h"
#include "MacControlInfo.h"

Define_Module(GWRouting);

/**
 * First we have to initialize the module from which we derived ours,
 * in this case BasicLayer.
 *
 **/
void GWRouting::initialize(int stage)
{
    BasicLayer::initialize(stage);

    if(stage == 0) {
        delayTimer = new cMessage( "delay-timer", SEND_RANN_TIMER );
 				rateCompute = new cMessage( "ratecompute", RATE_COMPUTE );
        rannheaderLength= par("rannheaderLength");
				netwheaderLength= par("netwheaderLength");
				macheaderLength= par("macheaderLength");
				applheaderLength= par("applheaderLength");

				//ETX metric stuff
				etxTimer = new cMessage( "etxTimer", SEND_PROBE );				
				etxheaderLength = par("etxheaderLength");				
				delayetx = par("delayetx");

				//LDAB stuff
				delayrate = par("delayrate");
				changeheaderLength = par("changeheaderLength");
				ratethreshold = par("ratethreshold");
 		}
    else if(stage==1) {
				delayrann = par("delayrann");
				delayrannbegin = par("delayrannbegin");
        scheduleAt(simTime() + delayrannbegin, delayTimer);
        myMACAddr = parentModule()->submodule("nic", -1)->id();
				//EV << " myMACAddr " << myMACAddr << endl;
        myNetwAddr = parentModule()->id();
        //EV << " myNetwAddr " << myNetwAddr << endl;
				numMNs = par("numMNs");
        //EV << " numMNs " << numMNs << endl;
				RANNSeqNumber = 0;
				numdropped = 0;
				
				//ETX metric stuff
				scheduleAt(simTime() + delayetx, etxTimer);

				//LDAB stuff
				scheduleAt(simTime() + delayrate, rateCompute);
    }
}

/**
 * A self-message with kind = SEND_RANN_TIMER indicates that a new
 * RANN packet has to be broadcasted (@ref sendRANN). 
 *
 * There are no other timer implemented for this module.
 *
 * @sa sendRANN
 **/
void GWRouting::handleSelfMsg(cMessage *msg) {
    switch( msg->kind() ){
		case SEND_PROBE:
		{
			  sendPROBE();	
		}
			break;
		case RATE_COMPUTE:
		{
			  if (computeRATE() > ratethreshold) {
						sendCHANGE();	
				}
				scheduleAt(simTime() + delayrate, rateCompute);
		}
			break;
    case SEND_RANN_TIMER: 
		{        
				sendRANN();
		// We don't delete the message because we use it afterwards
		}
	  	break;
    default:
    		EV << "Unkown selfmessage! -> delete, kind: "<<msg->kind() <<endl;
	  delete msg;
    }
}

/**
 * This function creates a new PROBE broadcast message and sends it down to
 * the mac layer
 **/
void GWRouting::sendPROBE()
{
		int macAddr = L2BROADCAST;
    PROBEPkt* probe = new PROBEPkt("PROBE_MESSAGE");
    probe->setNodeMACAddr(myMACAddr);
		
    probe->setLength(etxheaderLength);
    
    // set the control info to tell the layer 2 the mac address we want to send the PROBEPkt to;
		probe->setControlInfo( new MacControlInfo(macAddr) );    
    
 		// EV << "Sending appl. packet!\n";  // we must use sendDelayedDown, otherwise there is too much interference
    sendDelayedDown( probe,uniform(0,0.1) );
    		
    //EV << "Sending PROBE packet!\n";

		//std::cout << "probe sent at time " << simTime() << 
		//							" from node " << myMACAddr << std::endl;

 		// Then we set again the timer to send the PROBE message again 
   	scheduleAt(simTime() + delayetx, etxTimer);
}


/**
 * This function creates a new RANN broadcast message and sends it down to
 * the mac layer
 **/
void GWRouting::sendRANN()
{
		int macAddr = L2BROADCAST;
    RANNPkt* rann = new RANNPkt("RANN_MESSAGE");
    rann->setSrcGWMACAddr(myMACAddr);
		rann->setRANNSeqNumber(RANNSeqNumber++);   
    rann->setFwdNodeMACAddr(myMACAddr);

    rann->setLength(rannheaderLength);
    
    // set the control info to tell the layer 2 the mac address we want to send the RANNPkt to;
		rann->setControlInfo( new MacControlInfo(macAddr) );    
    
    sendDown( rann );		
    //EV << "Sending RANN packet!\n";

 		// Then we set again the timer to send the RANN message again 
   	scheduleAt(simTime() + delayrann, delayTimer);
}


/**
 * This function sends a CHANGE message to a random Mesh Node
 * 
 **/

void GWRouting::sendCHANGE()
{

		int mnAddr;
  	/** @brief choose from the MNRT the sending MN with the worst ETX metric */
		double worstETX = 0.0;
	  MNRoutingTable::iterator it2;
		for(it2 = mnroutingtable.begin(); it2 != mnroutingtable.end(); ++it2) {
        if( ( ( simTime() - ((*it2)->time) ) < 0.2 ) && ( ((*it2)->ETX) > worstETX ) ) {
						worstETX = (*it2)->ETX;	
						mnAddr = (*it2)->destMNMACAddr;		
				}
    }
        
		// find the next hop toward that MN looking in the MNRT( mn routing table ) 

		MNRoutingTable::iterator it = findMN(mnAddr);
		int nextHop = (*it)->nextHopMacAddr;
		
		
    CHANGEPkt* change = new CHANGEPkt("CHANGE_MESSAGE");
    change->setGWMACAddr(myMACAddr);
		change->setMNMACAddr(mnAddr);   
    
    change->setLength(changeheaderLength);
    
    // set the control info to tell the layer 2 the mac address we want to send the RANNPkt to;
		change->setControlInfo( new MacControlInfo(nextHop) );    
    
    sendDown( change );		
    //EV << "Sending RANN packet!\n";
		std::cout << "Sending CHANGE to MN " << mnAddr << " at time " << simTime() << std::endl;
}


/**
 * Redefine this function if you want to process messages from lower
 * layers
 *
 * If you want to forward the message to upper layers please use
 * @ref sendUp which will take care of decapsulation
 **/
void GWRouting::handleLowerMsg(cMessage* msg)
{
// based on the message arriving to the gateway the module takes different actions 
		
		// if the message is a rann, simply delete it
		if (dynamic_cast<RANNPkt*>(msg) != NULL)
		{
				RANNPkt* rann = (RANNPkt *)msg;
				delete rann;
				//EV << "RANN arrived, delete it" << endl;
				return;
		}

		// if the message is a RREP, update the MN Routing Table of the Gateway
		else if (dynamic_cast<RREPPkt*>(msg) != NULL)
		{
    		RREPPkt* rrep = (RREPPkt *)msg;

				// std::cout << "rrep received" << std::endl;
				
				// check if we are the destination
				if (myMACAddr != rrep->getDstGWMACAddr()) {
					 delete rrep;
					 EV << "Wrong RREP arrived, delete it" << endl;		
           return; 
				}

		    //mac address of the previous node from which we received the rrep packet
				int previousMacAddr = rrep->getFwdNodeMACAddr();

				int srcMNAddress = rrep->getSrcMNMACAddr();
				//EV << "srcMNAddress = " << srcMNAddress << endl;

				//get the ETX metric to that MN
				double etx = rrep->getETX();

				// look up for that Mesh Node in the MNRoutingTable
    		MNRoutingTable::iterator it = findMN(srcMNAddress);

				// if findMN() returns an iterator inside the mnroutingtable -> update the previous MN
    		if(it != mnroutingtable.end()) {
					(*it)->nextHopMacAddr = previousMacAddr;
					(*it)->ETX = etx;
				}

				// otherwise if the MN is new -> add it to the MNRoutingTable 
    		else {
					MNRoutingEntry* entry = new MNRoutingEntry; 
        	entry->destMNMACAddr = srcMNAddress;
        	entry->nextHopMacAddr = previousMacAddr;
					entry->ETX = etx;
					entry->time = 0.0;
					mnroutingtable.push_back(entry);
					//std::cout << "Insert new MN in the MN Routing Table = " << " MN Address = " << srcMNAddress << endl;
				}
				// delete the rrep: the GW doesnt need to rebroadcast the rrep packet
				delete rrep;
				return;
		}

		// if the message is an appl. packet, sendUp to the application layer or delete it
		else if (dynamic_cast<NetwPkt*>(msg) != NULL)
		{

    		NetwPkt* pkt = (NetwPkt *)msg;
				//std::cout << "netw pkt received" << std::endl;
		
		// check if the packet is directed to me or another MN or GW
				
				// read the destination of the packet
				int dstMACAddress = pkt->getDstMACAddr();
				//EV << "dstNetwAddress = " << dstMACAddress << endl;		
				
				// if the packet is destined to me  
				if ( dstMACAddress == myMACAddr ) 
				{
					//call function to compute rate
					feedRATE();
					//set the SimTime for that MN in the MNRT
					setSimTime(pkt);
							
					sendUp(decapsMsg(pkt));
				}
				// else delete it
				else 
				{					
					delete pkt;
				}
				return;
		}

		// if the message is a GW_REQ packet
		else if (dynamic_cast<GWREQPkt*>(msg) != NULL)
		{
				GWREQPkt* gwreq = (GWREQPkt *)msg;

				std::cout << "GWREQ packet received" << std::endl;					

				int dstGWMACAddress = gwreq->getGWMACAddr();

				// if the packet is destined to me  
				if ( dstGWMACAddress == myMACAddr ) 
				{
						//check if we can afford new MNs
						if (computeRATE() < ratethreshold)
						{
								sendGWREP(gwreq->getMNMACAddr());
								delete gwreq;
								
						}
						else 
						{					
								delete gwreq;
						}
										
				}
				else 
				{					
						delete gwreq;
				}
				return;
		}
		// if the message is unknown, simply delete it
		else
		{
				delete msg;
				EV << "unknown type message arrived" << endl;
				return;			
		}

}

/**
 * Redefine this function if you want to process messages from lower
 * layers before they are forwarded to upper layers
 *
 *
 * If you want to forward the message to upper layers please use
 * @ref sendUp which will take care of decapsulation and thelike
 **/
void GWRouting::handleLowerControl(cMessage* msg)
{
		numdropped++;
		if (ev.isGUI()) updateDisplay();
		delete msg;
		return;
		
}

/**
 * This function processes messages from upper
 * layers before they are send to lower layers.
 *
 * For the simulation we just choose randomly a MN destination and look up in the MNRT to get 
 * the next hop.
 *
 * To forward the message to lower layers after processing it please
 * use @ref sendDown. It will take care of anything needed
 **/
void GWRouting::handleUpperMsg(cMessage* msg)
{
		ApplPkt* pkt = static_cast<ApplPkt* >(msg);
    sendDown(encapsMsg(pkt));
}

/**
 * Encapsulates the ApplPkt, received by the appl. module, into a NetwPkt and set all needed
 * header fields.
 **/
NetwPkt* GWRouting::encapsMsg(ApplPkt *msg) {    
    
		// we have to choose a destination MN to which send the flow among the available MN
		MNRoutingTable::iterator it;
				
		for(it = mnroutingtable.begin(); it != mnroutingtable.end(); ++it)
		{
			iterators.push_back(it);
		}
		int vectorsize = iterators.size();

		int chosenpointer = intuniform(0,vectorsize-1);
		
		MNRoutingTable::iterator it2 = iterators[chosenpointer];
		
		iterators.clear();

		int nextHop = (*it2)->nextHopMacAddr; 
		
		// create a new NetwPkt with the same name and type of the appl. paket
    NetwPkt *pkt = new NetwPkt(msg->name(), msg->kind());
    pkt->setLength(netwheaderLength); 

    pkt->setSrcMACAddr(myMACAddr);
    pkt->setDstMACAddr((*it2)->destMNMACAddr);
    
    pkt->setControlInfo(new MacControlInfo(nextHop));
    
    //encapsulate the application packet
    pkt->encapsulate(msg);
    return pkt;
}


/**
 * Decapsulates the Network packet received from the Maclayer 
 **/
cMessage* GWRouting::decapsMsg(NetwPkt *msg) 
{
    cMessage* m = msg->decapsulate();
    // delete the netw packet
    delete msg;
    return m;
}

void GWRouting::feedRATE()
{
		sample.push_back(simTime());
}

double GWRouting::computeRATE()
{
//		conta gli elementi e dividi per la differenza del tempo, poi eliminali
			int samplesize = sample.size();

			if (samplesize < 2) {
					 
					std::cout << " 0.0 bps " << std::endl;
					return 0.0;					
			}
	
			double timing = sample.back() - sample.front();
			double inbitrate = ((192 + applheaderLength + netwheaderLength + macheaderLength)*samplesize)/timing;
						
			sample.clear();
			 
			

			std::cout << inbitrate << " bps " << std::endl;
						
			return inbitrate;
}

void GWRouting::sendGWREP(int id)
{

		// find the next hop toward that MN looking in the MNRT( mn routing table ) 

		MNRoutingTable::iterator it = findMN(id);
		int nextHop = (*it)->nextHopMacAddr;
		
		GWREPPkt* gwrep = new GWREPPkt("GWREP_MESSAGE");
    gwrep->setGWMACAddr(myMACAddr);
		gwrep->setMNMACAddr(id);   
    
    gwrep->setLength(changeheaderLength);
    
    // set the control info to tell the layer 2 the mac address we want to send the RANNPkt to;
		gwrep->setControlInfo( new MacControlInfo(nextHop) );    
    
    sendDown( gwrep );		
    //EV << "Sending RANN packet!\n";
		std::cout << "Sending GWREP to MN " << id << " at time " << simTime() << std::endl;
		return;
}

void GWRouting::setSimTime(NetwPkt* pkt)
{
		int mnAddr = pkt->getSrcMACAddr();
		MNRoutingTable::iterator it = findMN(mnAddr);
		(*it)->time = simTime();	
		return;	
				
}

void GWRouting::updateDisplay()
{
    char buf[20];
    sprintf(buf, "dropped: %ld", numdropped);
    parentModule()->submodule("nic", -1)->displayString().setTagArg("t",0,buf);

}


void GWRouting::finish() 
{
    
    if(!delayTimer->isScheduled()) 
			delete delayTimer;
		std::cout << simTime() << std::endl;

}

