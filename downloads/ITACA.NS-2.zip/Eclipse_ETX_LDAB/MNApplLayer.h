/* -*- mode:c++ -*- ********************************************************
 * file:        MNApplLayer.h
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 University of Trento
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA routing protocol
 * description: application layer: simple class for the application layer
 **************************************************************************/


#ifndef MN_APPL_LAYER_H
#define MN_APPL_LAYER_H

#include "BasicApplLayer.h"


/**
 * @brief My class for the application layer
 * 
 * In this implementation a Mesh Node sends some appl. packets toward a GW chosen by the 
 * routing layer according to the best Global Metric. The packet is forwarded toward the chosen GW
 * in a multi-hop way across the mesh router nodes.
 * 
 * @author Stefano Maurina
 **/
class MNApplLayer : public BasicApplLayer
{

protected:
		// for collecting statistics 
		cDoubleHistogram pktDelayStats;
    /** @brief cMessage pointer to be used as a self-message */
    cMessage *delayTimer;
		/** @brief boolean variable to decide if a mesh node sends or not appl packets */
		bool sendappl;
		/** @brief cached variable of the time the first appl packet is sent */
		int delayapplbegin;
		/** @brief cached variable of the time between the delivery of two appl. packets */
		double appltimer;
		/** @brief cached variable of the time after which the GW doesn't send any more packets */
		int stopappltime;
		/** @brief to get an overview at runtime how many messages each MN has sent */
		long numSent;
		/** @brief to get an overview at runtime how many messages each MN has received */
		long numReceived;
		/** @brief to get an overview at runtime how many total messages have been sent by all the MNs */
		static long totSent;
		/** @brief to get an overview at runtime how many total messages have been received by all the MNs */
		static long totReceived;

public:
    Module_Class_Members( MNApplLayer, BasicApplLayer, 0 );

    /** @brief Initialization of the module and some variables*/
    virtual void initialize(int);
    virtual void finish();

    enum APPL_MSG_TYPES{
			SEND_APPL_PACKET_TIMER
  	};
   
protected:
    /** @brief Handle self messages such as timer... */
    virtual void handleSelfMsg(cMessage*);

    /** @brief Handle messages from lower layer */
    virtual void handleLowerMsg(cMessage*);
  
    /** @brief send an appl packet toward a Gw that will be chosen by the routing layer */
    void sendApplPacket();

    /** @brief update the numer of appl. messages sent and received on the GUI */
	  void updateDisplay();

};

#endif
