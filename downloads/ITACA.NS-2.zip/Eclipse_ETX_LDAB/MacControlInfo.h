/* -*- mode:c++ -*- *******************************************************
 * file:        MacControlInfo.h
 *
 * author:      Stefano Maurina
 *
 * copyright:   2008  University of Trento
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 **************************************************************************
 * part of:     TBMGA Routing Implementation
 * description: control info to pass the mac addresses between the 
 *              routing and mac layer
 **************************************************************************/

#ifndef MACCONTROLINFO_H
#define MACCONTROLINFO_H

#include <omnetpp.h>

/**
 * @brief Control info mac messages
 * 
 * Control Info to pass interface information from the routing to the
 * mac layer and vice versa. The routing layer passes the
 * next-hop mac address to the mac layer, whereas the mac
 * layer uses the control info to pass the mac address of the node
 * from which he received the frame (previous hope) to the routing layer
 *
 * 
 * @author Stefano Maurina
 **/
class MacControlInfo : public cPolymorphic
{
  protected:
    /** @brief mac address of the next or previous node*/
    int nextHopMac;

  public:
    /** @brief Default constructor*/
    MacControlInfo(const int addr) : nextHopMac(addr) {};
    /** @brief Destructor*/
    virtual ~MacControlInfo(){};

    /** @brief Getter method*/
    virtual const int getNextHopMac() {
	return nextHopMac;
    };

    /** @brief Setter method*/
    virtual void setNextHopMac(const int addr){
	nextHopMac = addr;
    };
};


#endif
