/***************************************************************************
 * file:        MNApplLayer.cc
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 University of Trento 
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA routing protocol
 * description: application layer: simple class for the application layer
 ***************************************************************************/


#include "MNApplLayer.h"

Define_Module(MNApplLayer);

/**
 * First we have to initialize the module from which we derived ours,
 * in this case BasicModule.
 *
 *
 **/
void MNApplLayer::initialize(int stage)
{
    BasicApplLayer::initialize(stage);
    if(stage == 0) {
				pktDelayStats.setName("pkDelayStats");
        delayTimer = new cMessage( "delay-timer", SEND_APPL_PACKET_TIMER );
				sendappl = par("sendappl");
				numSent = 0;
				numReceived = 0;
    }
    else if(stage==1) {
				if(sendappl==true) {
					delayapplbegin = par("delayapplbegin");
					stopappltime = par("stopappltime");
					appltimer = par("appltimer");					
					scheduleAt(simTime() + delayapplbegin, delayTimer);
				}
				else {
					EV<< "This MN doesn't send appl. packets " << endl;
				}
    }
}

/** definition of the static member totSent */
long MNApplLayer::totSent = 0;

/** definition of the static member totReceived */
long MNApplLayer::totReceived = 0;

/**
 * There is only one kind of message that can arrive at this module: ApplPkt
 * 
 **/
void MNApplLayer::handleLowerMsg( cMessage* msg )
{	
		if (dynamic_cast<ApplPkt*>(msg) != NULL)
		{
			ApplPkt* pkt = (ApplPkt *)msg;
			pktDelayStats.collect(simTime() - pkt->timestamp());
			// update the counters
			numReceived++;
			totReceived++;
			// update the GUI
    	if (ev.isGUI()) {
				updateDisplay();
			}
			// delete the appl. packet
			delete msg;
		}
    else 
		{ 
			EV << "unknown type message" << endl;
			delete msg;
		}   
}


/**
 * A timer with kind = SEND_APPL_PACKET_TIMER indicates that a new
 * appl. message has to be send (@ref sendApplPacket). 
 *
 * There are no other timer implemented for this module.
 *
 * @sa sendBroadcast
 **/
void MNApplLayer::handleSelfMsg(cMessage *msg) {
    switch( msg->kind() ){
    	case SEND_APPL_PACKET_TIMER:
			{
            	sendApplPacket();
			}
				break;
    	default:
    		EV << "Unkown selfmessage! -> delete, kind: "<<msg->kind() <<endl;
				delete msg;
    }
}


/**
 * This function creates a new appl. message and sends it down to
 * the network layer
 **/
void MNApplLayer::sendApplPacket()
{
    ApplPkt *pkt = new ApplPkt("APPL_MESSAGE");

		// we don't set the destination: the routing module will choose the destination GW based 
		// on the global metric.
    
		pkt->setSrcAddr( myApplAddr() );
    pkt->setLength( headerLength );
		pkt->setTimestamp();  //for statistical collection
    
		   
		 // EV << "Sending appl. packet!\n";
    sendDelayedDown( pkt,uniform(0,0.1) );

 		// We set again the timer to send the appl. message again 
		if (simTime() < stopappltime)
		scheduleAt(simTime() + appltimer, delayTimer);

		// update the counter
		numSent++;
		totSent++;
		// update the GUI
    if (ev.isGUI()) {
				updateDisplay();
		}
}

void MNApplLayer::finish() 
{
    BasicApplLayer::finish();
    if(!delayTimer->isScheduled()) delete delayTimer;

		recordScalar("#totalnumSent", totSent);
}

void MNApplLayer::updateDisplay()
{
		// display numSent and numReceived
    char buf[40];
    sprintf(buf, "sent: %ld rcvd: %ld", numSent, numReceived);
    parentModule()->displayString().setTagArg("t",0,buf);
	
		// display totalnumSent
		char totalbuf[20];
    sprintf(totalbuf, "totMNsent: %ld", totSent);
    parentModule()->parentModule()->displayString().setTagArg("t",0,totalbuf);

		// display totalnumReceived
		char totalbuf2[20];
    sprintf(totalbuf2, "totMNreceived: %ld", totReceived);
    parentModule()->parentModule()->displayString().setTagArg("t",3,totalbuf2);
}


