/***************************************************************************
 * file:        MNRouting.cc
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 
 *              
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA Routing Protocol
 * description: Routing layer of the Mesh Nodes
 *               
 ***************************************************************************/


#include "MNRouting.h"
#include "MacControlInfo.h"
#include "TimerPkt_m.h"

Define_Module(MNRouting);


/**
 * First we have to initialize the module from which we derived ours,
 * in this case BasicLayer.
 *
 **/
void MNRouting::initialize(int stage)
{
    BasicLayer::initialize(stage);

      if(stage == 0) {
				rrepheaderLength= par("rrepheaderLength");
			  netwheaderLength= par("netwheaderLength");
				gwreqheaderLength= par("gwreqheaderLength");
				macheaderLength= par("macheaderLength");
				applheaderLength= par("applheaderLength");
				//ETX metric stuff
				etxTimer = new cMessage( "etxTimer", SEND_PROBE );				
				etxheaderLength = par("etxheaderLength");				
				delayetx = par("delayetx");
				defaultGW = 0;
				lastGWREPtime = 0.0;
				appltimer= par("appltimer");
      }
      else if(stage==1) {
				myMACAddr = parentModule()->submodule("nic", -1)->id();
				myNetwAddr = parentModule()->id();
        //EV << " myMACAddr " << myMACAddr << endl;
        //EV << " myNetwAddr " << myNetwAddr << endl;
				numGWs = par("numGWs");
        //EV << " numGWs " << numGWs << endl;
      	timer = par("timer");
        //EV << " timer " << timer << endl;
				numdropped = 0;
				//ETX metric stuff
				scheduleAt(simTime() + delayetx, etxTimer);
				estimrate = ( 192 + applheaderLength + netwheaderLength + macheaderLength )/appltimer;
			}
}

/**
 * This function processes messages from upper
 * layers before they are send to lower layers.
 *
 *
 * To forward the message to lower layers after processing it please
 * use @ref sendDown. It will take care of anything needed
 **/
void MNRouting::handleUpperMsg(cMessage* msg)
{
		ApplPkt* pkt = static_cast<ApplPkt* >(msg);
    sendDown(encapsMsg(pkt));
	
}

/**
 * Redefine this function if you want to process messages from lower
 * layers 
 *
 * If you want to forward the message to upper layers please use
 * @ref sendUp which will take care of decapsulation 
 **/
void MNRouting::handleLowerMsg(cMessage* msg)
{

// based on the message arriving to the MN the module takes different actions 
		if (dynamic_cast<PROBEPkt*>(msg) != NULL)
		{							
				PROBEPkt* probe = (PROBEPkt *)msg;
				//std::cout << "MN " << myMACAddr << ":probe received at time " << simTime() << 
				//					" from node " << probe->getNodeMACAddr() << std::endl;

				feedmapetx(probe);
				delete probe;
				return;
		}

		else if (dynamic_cast<RANNPkt*>(msg) != NULL)
		{
		    
    		RANNPkt* rann = (RANNPkt *)msg;
				//std::cout << "MN " << myMACAddr << ":rann received at time " << simTime() << 
				//					" from node " << rann->getFwdNodeMACAddr() << std::endl;

				// update the hopCount metric
				// rann->setHopCount((rann->getHopCount()) + 1);
  			//EV << "hopCount = " << rann->getHopCount() << endl;				
				
				int prevHop = rann->getFwdNodeMACAddr();
				// compute the etx metric
				rann->setETX((rann->getETX()) + computeETX(prevHop));

				// update the etx metric 


				checkAndUpdateCRT(rann);
				return;

		}

		else if (dynamic_cast<RREPPkt*>(msg) != NULL)
		{
    		RREPPkt* rrep = (RREPPkt *)msg;

						
				// update the mesh node routing table
				updateMNRT(rrep);
				return;

		}

		else if (dynamic_cast<NetwPkt*>(msg) != NULL)
		{
    		NetwPkt* pkt = (NetwPkt *)msg;

			// check if the packet is directed to me or another MN or GW
				
				// read the destination of the packet
				int dstMACAddress = pkt->getDstMACAddr();
				
				// if the packet is destined to me  
				if ( dstMACAddress == myMACAddr ) 
				{
					sendUp(decapsMsg(pkt));
					return;
				}
				// else look up in the GWRT and in the MNRT to find that destination address and forward it
				else 
				{					
					// forward the appl. packet
					forwardAppl(pkt);
					return;				
				}
		}

		else if (dynamic_cast<CHANGEPkt*>(msg) != NULL)
		{
    		CHANGEPkt* change = (CHANGEPkt *)msg;

				int dstMNMACAddr = change->getMNMACAddr();
				// if the packet is destined to me  
				if ( dstMNMACAddr == myMACAddr ) 
				{				
						std::cout << "MN " << myMACAddr << " received change request at " << simTime() << endl;

						int srcCHANGEPkt = change->getGWMACAddr();
						
						if (srcCHANGEPkt == defaultGW)
						{
								//inviare in sequenza ai GW un GWREQ escludendo quello da cui ho ricevuto il changepkt
								GWRoutingTable::iterator it;
								for(it = gwroutingtable.begin(); it != gwroutingtable.end(); ++it) {
										if( (*it)->destGWMACAddr != srcCHANGEPkt ) {
												sendGW_REQ((*it)->destGWMACAddr);
										}
								}
						}
						
						delete change;
						return;
				}
        //else look up in the MNRT to find that destination and forward it   
				else  
				{
						//forward the change packet					
						forwardCHANGE(change);						
						return;
				}
		}

		else if (dynamic_cast<GWREPPkt*>(msg) != NULL)
		{
    		GWREPPkt* gwrep = (GWREPPkt *)msg;

				int dstMNMACAddr = gwrep->getMNMACAddr();
				// if the packet is destined to me  
				if ( dstMNMACAddr == myMACAddr ) 
				{				
						std::cout << "MN " << myMACAddr << " received GWREP request at " << simTime() << endl;
						if ( (simTime() - lastGWREPtime) > 3.0 ) //so to avoid also too much pin-pong
						{
							lastGWREPtime = simTime(); 
							defaultGW = gwrep->getGWMACAddr();
						}
						delete gwrep;
						
				}
        //else look up in the MNRT to find that destination and forward it   
				else  
				{
						//forward the gwrep packet					
						forwardGWREP(gwrep);						
						
				}
				return;
		}
		
		else if (dynamic_cast<GWREQPkt*>(msg) != NULL)
		{
    		GWREQPkt* gwreq = (GWREQPkt *)msg;

				forwardGWREQ(gwreq);
				return;
		}

		else
		{ 
				EV << "unknown type message" << endl;
				delete msg;
				return;
		}

}

/**
 * A self-message with kind = TIMER_MESSAGE indicates that a new
 * RREP packet has to be sent toward a gateway (@ref sendRREP). 
 *
 * A self-message with kind = PROBE_MESSAGE indicates that a new
 * PROBE packet must be sent (@ref sendPROBE). 
 *
 * @sa sendRREP
 **/
void MNRouting::handleSelfMsg(cMessage *msg) {
    switch( msg->kind() ){
		case SEND_PROBE:
		{
			  sendPROBE();	
		}
			break;
    case TIMER_MESSAGE:
		{
				TimerPkt* timerMessage = static_cast<TimerPkt* >(msg);
				// take the information about the GW to update in the GW Routing Table from the timerMessage 
				int destGWAddress = timerMessage->getGWMACAddr();
				
				// delete the timer self-message
				delete timerMessage;

				// take the information from the Cache Routing Table
				RoutingCacheTable::iterator it1 = findGWCRT(destGWAddress);
				unsigned int SN = (*it1)->RANNSeqNumb;
				int nextHop = (*it1)->potentialNextHopMacAddr;
				double ETX = (*it1)->ETX;

		// update the GW Routing Table

				// check if that gateway is already inside the gw routing table 
		    GWRoutingTable::iterator it2 = findGWGRT(destGWAddress);
				
 				// if findGWGRT() returns an iterator inside the gw routing table...
    		if(it2 != gwroutingtable.end()) 
				{	
						(*it2)->RANNSeqNumb = SN;
						(*it2)->nextHopMacAddr = nextHop;
						(*it2)->ETX = ETX;
        }
				// otherwise, if that address there wasn't, add the new gateway
    		else 
				{
						// create a new struct routing cache entry  
						GWRoutingEntry* entry = new GWRoutingEntry; 

			      entry->destGWMACAddr = destGWAddress;
		        entry->RANNSeqNumb = SN;
		        entry->nextHopMacAddr = nextHop;
		        entry->ETX = ETX;
		        gwroutingtable.push_back(entry);
						//std::cout << "Insert new Gateway in the GW Routing Table = " << " GW Address = " << destGWAddress << endl;
				}

       // send the new RREP message
			 int macAddr = nextHop;
       RREPPkt* rrep = new RREPPkt("RREP_MESSAGE");
       rrep->setSrcMNMACAddr(myMACAddr);
		   rrep->setDstGWMACAddr(destGWAddress);   
			 rrep->setFwdNodeMACAddr(myMACAddr);
			 rrep->setETX(ETX);

       rrep->setLength(rrepheaderLength);
    
    	 // set the control info to tell the mac layer the layer 2
    	 // address;
			 rrep->setControlInfo( new MacControlInfo(macAddr) );    
    
		   sendDown( rrep );		
    	 //EV << "Sending RREP packet!\n";
			 return;

		}
			break;
    default:
    	EV << "Unkown selfmessage! -> delete, kind: "<< msg->kind() << endl;
			delete msg;
    }
}

void MNRouting::handleLowerControl(cMessage* msg)
{
		numdropped++;
		if (ev.isGUI()) updateDisplay();
		delete msg;
		return;
}

/**
 * This function creates a new PROBE broadcast message and sends it down to
 * the mac layer
 **/
void MNRouting::sendPROBE()
{
		int macAddr = L2BROADCAST;
    PROBEPkt* probe = new PROBEPkt("PROBE_MESSAGE");
    probe->setNodeMACAddr(myMACAddr);
		
    probe->setLength(etxheaderLength);
    
    // set the control info to tell the layer 2 the mac address we want to send the PROBEPkt to;
		probe->setControlInfo( new MacControlInfo(macAddr) );    
    
 		// EV << "Sending appl. packet!\n";  // we must use sendDelayedDown, otherwise there is too much interference
    sendDelayedDown( probe,uniform(0,0.1) );
    		
    //EV << "Sending PROBE packet!\n";

		//std::cout << "probe sent at time " << simTime() << 
		//							" from node " << myMACAddr << std::endl;

 		// Then we set again the timer to send the PROBE message again 
   	scheduleAt(simTime() + delayetx, etxTimer);
}

/**
 * compute the etx metric
 **/
double MNRouting::computeETX(int id)
{
		EtxTable::iterator it = findNeigh(id);
		
    if( it != etxTable.end() )  {
        
				//devo ottenere quanti elementi allinterno del vettore sono piu recenti di 10 secondi
				// gli altri li elimino, oppure elimino i vecchi e dopo vedo con beacon.size quanti ne 
				// sono rimasti
				
				//vector iterator
				Beacon::iterator itv;
				
				for ( itv = it->beacon.begin() ; itv < it->beacon.end(); itv++ )
    		{
						if ( *itv < ( simTime() - (10 * delayetx) ) )
								it->beacon.erase(itv);
				}
				
								
				double df = it->beacon.size()/10.0;
				//std::cout << "df = " << df << endl;

				if (df > 1)  
				{
					double etx = 1.0;
					//std::cout << "etx = " << etx << endl;
				  return etx;
				} 
				else if (df == 0)
				{
					double etx = 1000000.0;
					//std::cout << "etx = " << etx << endl;					
					return etx;
				}
				else 
				{
					double etx = 1.0/(df * df);
					//std::cout << "Im here -> etx = " << etx << endl;
					return etx;
				}
		}
		else {
		
				return 1000000;
		}

}


/**
 * feed the etx map
 **/
void MNRouting::feedmapetx(PROBEPkt* probe)
{
		// mac address of the node from which we received the probe packet
		int neighborMacAddr = probe->getNodeMACAddr();

		// check if that Neighbor is already inside the Etx Table 
    EtxTable::iterator it = findNeigh(neighborMacAddr);
		

    if( it != etxTable.end() )  {
        
				

				it->beacon.push_back(simTime());

				

		}
    else
    {
	      
				
				// create a new struct etx entry  
				EtxEntry entry;   

				//add the neighbor in the table and initialize the vector
				entry.NodeMACAddr = neighborMacAddr;
        entry.beacon.push_back(simTime());

				etxTable.push_back(entry);

		}
}

/**
 * check the Cache Routing Table and in case update it
 **/
void MNRouting::checkAndUpdateCRT(RANNPkt* rann)
{
		
    // mac address of the node from which we received the rann packet
		int previousMacAddr = rann->getFwdNodeMACAddr();

		// address of the gateway which sent the RANN
		int srcGWAddress = rann->getSrcGWMACAddr();
		//EV << "srcGWAddress = " << srcGWAddress << endl;

		// check if that gateway is already inside the cache routing table 
    RoutingCacheTable::iterator it = findGWCRT(srcGWAddress);
	
		
// if findGWCRT() returns an iterator inside the cacheroutingtable...
    if(it != cacheroutingtable.end()) 
		{
		// check the SN corresponding to that gateway 
				
					// if the sequence number of the rann is greater than the one stored in the cache 
					if ( (*it)->RANNSeqNumb < rann->getRANNSeqNumber() ) 
					{
							// update the corresponding routing cache entry
							(*it)->RANNSeqNumb = rann->getRANNSeqNumber();
							(*it)->potentialNextHopMacAddr = previousMacAddr;
							(*it)->ETX = rann->getETX();
							(*it)->time = rann->arrivalTime();

							// create a self-message to model the timer
							TimerPkt* timerMessage = new TimerPkt( "timerMessage", TIMER_MESSAGE );
							timerMessage->setGWMACAddr(srcGWAddress); 
							
							// schedule the timerMessage for a time timer
   						scheduleAt(simTime() + timer, timerMessage);

							// rebroadcast rann
							rebroadcastRANN(rann);
							//EV << "Rebroadcast RANN packet" << endl; 
							return;
					}
					// if the sequence number of the rann is equal to the one stored in the cache  
					// and the timer hasn't still elapsed
					else if ( ((*it)->RANNSeqNumb == rann->getRANNSeqNumber())	&& (((rann->arrivalTime())-((*it)->time)) < timer) ) 
					{
								// if the ETX metric of the new rann is better
								if ( rann->getETX() < (*it)->ETX ) 
								{
										(*it)->potentialNextHopMacAddr = previousMacAddr;						
										(*it)->ETX = rann->getETX();
										
										// rebroadcast rann
										rebroadcastRANN(rann);
										EV << "Rebroadcast RANN packet" << endl;
										return;
								}
								// if the ETX metric of the new rann is worse
								else 
								{
										// delete the rann because its metric is worse
  									delete rann;
										//EV << "rann deleted" << endl;
										return;
								}
					}					
					// if the rann has a lower sn or the timer is elapsed
					else  {
								// delete the rann because its information is old
  							delete rann;
								//EV << "rann deleted" << endl;		
								return;			
					}
		}

// otherwise, if that address there wasn't, add the new gateway
    else 
		{
				// create a new struct routing cache entry  
				RoutingCacheEntry* entry = new RoutingCacheEntry;   

	      entry->destGWMACAddr = srcGWAddress;
        entry->RANNSeqNumb = rann->getRANNSeqNumber();
        entry->potentialNextHopMacAddr = previousMacAddr;
        entry->ETX = rann->getETX();
				entry->time = rann->arrivalTime();
        cacheroutingtable.push_back(entry);
				//std::cout << "Insert new Gateway in the RoutingCacheTable = " << " GW Address = " << srcGWAddress << endl;

				// create a self-message to model the timer
				TimerPkt* timerMessage = new TimerPkt( "timerMessage", TIMER_MESSAGE );
				timerMessage->setGWMACAddr(srcGWAddress); 
							
				// schedule the timerMessage for a time timer
   			scheduleAt(simTime() + timer, timerMessage);
				
				// rebroadcast rann
				rebroadcastRANN(rann);
				//EV << "Rebroadcast RANN packet" << endl;
        return;    
    }
}


/**
 * This function updates the mesh node routing table (MNRT) upon receiving a rrep from a MN
 **/
void MNRouting::updateMNRT(RREPPkt* rrep)
{
		// mac address of the previous node from which we received the rrep packet
		int previousMacAddr = rrep->getFwdNodeMACAddr();

		// read the MN source of the rrep
		int srcMNAddress = rrep->getSrcMNMACAddr();
		//EV << "srcMNAddress = " << srcMNAddress << endl;

		// check if this MN is already in the MNRT
 		MNRoutingTable::iterator it = findMN(srcMNAddress);

		// if findMN() returns an iterator inside the mnroutingtable
    if(it != mnroutingtable.end()) {
				// update the next hop mac address in the MNRT entry
				(*it)->nextHopMacAddr = previousMacAddr;
		}

		// otherwise, if that MN there wasn't, add the new MN
    else {
				MNRoutingEntry* entry = new MNRoutingEntry;
       	entry->destMNMACAddr = srcMNAddress;
       	entry->nextHopMacAddr = previousMacAddr;
				mnroutingtable.push_back(entry);
				//std::cout << "Insert new MN in the MNRoutingTable = " << " MN Address = " << srcMNAddress << endl;
		}

		// send the rrep along the tree toward the gateway
		forwardRREP(rrep);
		return;
}


/**
 * This function rebroadcast a RANN message 
 **/
void MNRouting::rebroadcastRANN(RANNPkt* rann)
{

		int macAddr = L2BROADCAST;

		//set my MAC Address as the forwarding Node
		rann->setFwdNodeMACAddr( myMACAddr );

    // set the control info to tell the mac layer the layer 2
    // address;
    rann->setControlInfo( new MacControlInfo(macAddr) );
	    
		// send the paket to the mac layer
    sendDown( rann );
		
    EV << "Rebroadcasting RANN packet!\n";
		return;
		
}


/**
 * This function forwards a RREP message toward a Gateway 
 **/
void MNRouting::forwardRREP(RREPPkt* rrep)
{
		// read the GW source of the rrep
		int dstGWAddress = rrep->getDstGWMACAddr();
		//EV << "dstGWAddress = " << dstGWAddress << endl;
		
    // set my MAC Addr as the forwarding Node
		rrep->setFwdNodeMACAddr( myMACAddr );

		// check the entry in the GW routing table for this GW
 		GWRoutingTable::iterator it = findGWGRT(dstGWAddress);

		// take the nextHop from the GWRT and set it as the macAddr
		int macAddr = (*it)->nextHopMacAddr;

    // set the control info to tell the mac layer the layer 2
    // address;
    rrep->setControlInfo( new MacControlInfo(macAddr) );

		// send the paket to the mac layer
    sendDown( rrep );
    //EV << "Forwarding RREP packet!\n";
    return;
}


/**
 * This function computes the global metric upon receiving a new flow from 
 * the upper layers. In this case it just uses the minimum hop count.
 *
 **/
int MNRouting::globalMetric()
{

 /** @brief choose the best GW in the GRT based on the ETX metric */
		// initialize the global metric
		GWRoutingTable::iterator itGW = gwroutingtable.begin();
		double minglobalmetric = (*itGW)->ETX;
	  GWRoutingTable::iterator it;
				for(it = ++gwroutingtable.begin(); it != gwroutingtable.end(); ++it) {
            if((*it)->ETX < minglobalmetric) {
								minglobalmetric = (*it)->ETX;	
								itGW = it;		
						}
        }
        return (*itGW)->destGWMACAddr;
     
}


/**
 * Encapsulates the ApplPkt, received by the appl. module, into a NetwPkt and set all needed
 * header fields.
 **/
NetwPkt* MNRouting::encapsMsg(ApplPkt *msg) {    
    
    if ( defaultGW == 0 ) 
		{
				defaultGW = globalMetric();
		}
			
		// find the next hop for that gateway looking in the GWGRT( gw routing table ) 
 		GWRoutingTable::iterator it = findGWGRT(defaultGW);

		int nextHop = (*it)->nextHopMacAddr; 

 		// create a new NetwPkt with the same name and type of the appl. paket
 		NetwPkt *pkt = new NetwPkt(msg->name(), msg->kind());
 		pkt->setLength(netwheaderLength); 

 		pkt->setSrcMACAddr(myMACAddr);
 		pkt->setDstMACAddr(defaultGW);
    
 		pkt->setControlInfo(new MacControlInfo(nextHop));
    
 		//encapsulate the application packet
 		pkt->encapsulate(msg);
    return pkt;
}


/**
 * Decapsulates the Network packet received from the Maclayer 
 **/
cMessage* MNRouting::decapsMsg(NetwPkt *msg) 
{
    cMessage* m = msg->decapsulate();

    // delete the netw packet
    delete msg;
    return m;
}

/**
 * This function forward an Appl. message toward a Gateway or a MN
 **/
void MNRouting::forwardAppl(NetwPkt* pkt)
{
		// read the destination of the pkt
	  int dstMACAddress = pkt->getDstMACAddr();
		
		// check before the entry in the GW routing table for this GW
 		GWRoutingTable::iterator it = findGWGRT(dstMACAddress);
		
		if (it != gwroutingtable.end())
		{ 

			// take the nextHop from the GWRT and set it as the macAddr next hop
			int macAddr = (*it)->nextHopMacAddr;

    	// set the control info to tell the mac layer the layer 2
    	// address;
    	pkt->setControlInfo( new MacControlInfo(macAddr) );

			// send the paket to the mac layer
    	sendDown( pkt );
    	//EV << "Forwarding appl. packet!\n";
			return;
		}
		
		// else the destination is a MN
		else 
		{
			MNRoutingTable::iterator it = findMN(dstMACAddress);
			// take the nextHop from the MNRT and set it as the macAddr next hop
			int macAddr = (*it)->nextHopMacAddr;

    	// set the control info to tell the mac layer the layer 2
    	// address;
    	pkt->setControlInfo( new MacControlInfo(macAddr) );

			// send the paket to the mac layer
    	sendDown( pkt );
    	//EV << "Forwarding appl. packet!\n";
			return;
		}	
}

/**
 * This function forward a CHANGE message toward a MN
 **/
void MNRouting::forwardCHANGE(CHANGEPkt* pkt)
{
		// read the destination of the pkt
	  int dstMNMACAddr = pkt->getMNMACAddr();
		
		MNRoutingTable::iterator it = findMN(dstMNMACAddr);
		// take the nextHop from the MNRT and set it as the macAddr next hop
		int macAddr = (*it)->nextHopMacAddr;

    // set the control info to tell the mac layer the layer 2
    // address;
    pkt->setControlInfo( new MacControlInfo(macAddr) );

		// send the paket to the mac layer
    sendDown( pkt );
    //EV << "Forwarding appl. packet!\n";
		return;
}

/**
 * This function forward a GWREP message toward a MN
 **/
void MNRouting::forwardGWREP(GWREPPkt* gwrep)
{

		// read the destination of the gwrep
	  int dstMNMACAddr = gwrep->getMNMACAddr();
		
		MNRoutingTable::iterator it = findMN(dstMNMACAddr);
		// take the nextHop from the MNRT and set it as the macAddr next hop
		int macAddr = (*it)->nextHopMacAddr;

    // set the control info to tell the mac layer the layer 2
    // address;
    gwrep->setControlInfo( new MacControlInfo(macAddr) );

		// send the paket to the mac layer
    sendDown( gwrep );
    //EV << "Forwarding appl. packet!\n";
		return;
}

/**
 * This function forwards a GWREQ message toward a Gateway 
 **/
void MNRouting::forwardGWREQ(GWREQPkt* gwreq)
{
		// read the GW destination of the gwreq
		int dstGWAddress = gwreq->getGWMACAddr();
		
		// check the entry in the GW routing table for this GW
 		GWRoutingTable::iterator it = findGWGRT(dstGWAddress);

		// take the nextHop from the GWRT and set it as the macAddr
		int macAddr = (*it)->nextHopMacAddr;

    // set the control info to tell the mac layer the layer 2
    // address;
    gwreq->setControlInfo( new MacControlInfo(macAddr) );

		// send the paket to the mac layer
    sendDown( gwreq );
    //EV << "Forwarding GWREQ packet!\n";
    return;
}


void MNRouting::sendGW_REQ(int id)
{
		
		//build a GWREQPkt and send it
       
			 
			// check before the entry in the GW routing table for this GW
 			GWRoutingTable::iterator it = findGWGRT(id);
		
			// take the nextHop from the GWRT and set it as the macAddr next hop
			int macAddr = (*it)->nextHopMacAddr;

    	
       GWREQPkt* gwreq = new GWREQPkt("GWREQ_MESSAGE");
       gwreq->setMNMACAddr(myMACAddr);
		   gwreq->setGWMACAddr(id);   
			 gwreq->setEstimrate(estimrate);			 

       gwreq->setLength(gwreqheaderLength);
    
    	 // set the control info to tell the mac layer the layer 2
    	 // address;
			 gwreq->setControlInfo( new MacControlInfo(macAddr) );    
    
		   sendDown( gwreq );		
    	 //EV << "Sending GWREQ packet!\n";
			 return;		
				
}

void MNRouting::updateDisplay()
{
    char buf[20];
    sprintf(buf, "dropped: %ld", numdropped);
    parentModule()->submodule("nic", -1)->displayString().setTagArg("t",0,buf);
}

void MNRouting::finish() 
{
    
  EV << "Simulation ending" << endl;
}

