/* -*- mode:c++ -*- ********************************************************
 * file:        GWApplLayer.h
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 University of Trento
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA routing protocol
 * description: application layer: simple class for the application layer
 **************************************************************************/


#ifndef GW_APPL_LAYER_H
#define GW_APPL_LAYER_H

#include "BasicApplLayer.h"


/**
 * @brief My class for the application layer
 * 
 * In this implementation a GW sends some appl. packets toward a MN chosen randomly by the 
// routing layer. The packet is forwarded toward the chosen MN
 * in a multi-hop way across the mesh router nodes.
 * 
 * @author Stefano Maurina
 **/
class GWApplLayer : public BasicApplLayer
{

protected:
		// for collecting statistics 
		cDoubleHistogram pktDelayStats;
    /** @brief cMessage pointer to be used as a self-message */
    cMessage *delayTimer;
		/** @brief boolean variable to decide if a GW sends or not appl packets */
		bool sendappl;
		/** @brief cached variable of the time the first appl packet is sent */
		int delayapplbegin;
		/** @brief cached variable of the time between the delivery of two appl. packets */
	  double appltimer;
		/** @brief cached variable of the time after which the GW doesn't send any more packets */
		int stopappltime;
		/** @brief to get an overview at runtime how many messages each GW sent */
		long numSent;
		/** @brief to get an overview at runtime how many messages each GW received */
		long numReceived;
		/** @brief to get an overview at runtime how many messages have been sent by all the GWs */
		static long totalnumSent;
		/** @brief to get an overview at runtime how many messages have been received by all the GWs */
		static long totalnumReceived;

public:
    Module_Class_Members( GWApplLayer, BasicApplLayer, 0 );

    /** @brief Initialization of the module and some variables*/
    virtual void initialize(int);
    virtual void finish();

    enum APPL_MSG_TYPES{
			SEND_APPL_PACKET_TIMER
  	};
   
protected:
    /** @brief Handle self messages such as timer... */
    virtual void handleSelfMsg(cMessage*);

    /** @brief Handle messages from lower layer */
    virtual void handleLowerMsg(cMessage*);
  
    /** @brief send an appl packet toward a MN */
    void sendApplPacket();

    /** @brief update the number of appl. messages sent and received on the GUI */
		void updateDisplay();

};

#endif
