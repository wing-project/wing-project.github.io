/***************************************************************************
 * file:        GWApplLayer.cc
 *
 * author:      Stefano Maurina
 *
 * copyright:   (C) 2008 University of Trento 
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBMGA routing protocol
 * description: application layer: simple class for the application layer
 ***************************************************************************/


#include "GWApplLayer.h"

Define_Module(GWApplLayer);

/**
 * First we have to initialize the module from which we derived ours,
 * in this case BasicModule.
 *
 * 
 **/
void GWApplLayer::initialize(int stage)
{
    BasicApplLayer::initialize(stage);
    if(stage == 0) {
				pktDelayStats.setName("pkDelayStats");
        delayTimer = new cMessage( "delay-timer", SEND_APPL_PACKET_TIMER );
				sendappl = par("sendappl");
				numSent = 0;
				numReceived = 0;
    }
    else if(stage==1) {
				if(sendappl==true) {
					delayapplbegin = par("delayapplbegin");
					stopappltime = par("stopappltime");
					appltimer = par("appltimer");
				  scheduleAt(simTime() + delayapplbegin, delayTimer);
   			}
				else {
					EV<< "This GW doesn't send appl. packets " << endl;
				}
    }
}

/** definition of the static member totalnumSent */
long GWApplLayer::totalnumSent = 0;

/** definition of the static member totalnumSent */
long GWApplLayer::totalnumReceived = 0;

/**
 * There is only one kind of message that can arrive at this module: ApplPkt
 * 
 **/
void GWApplLayer::handleLowerMsg( cMessage* msg )
{	
		if (dynamic_cast<ApplPkt*>(msg) != NULL)
		{
			ApplPkt* pkt = (ApplPkt *)msg;
			pktDelayStats.collect(simTime() - pkt->timestamp());
			// update the counters
			numReceived++;
			totalnumReceived++;
			// update the GUI
    	if (ev.isGUI()) {
				updateDisplay();
			}
			// delete the appl. packet
			delete msg;
		}
    else 
		{ 
			EV << "unknown type message" << endl;
		  delete msg;
		}   		
}

/**
 * A timer with kind = SEND_APPL_PACKET_TIMER indicates that a new
 * appl. message has to be send (@ref sendApplPacket). 
 *
 * There are no other timer implemented for this module.
 *
 * @sa sendBroadcast
 **/
void GWApplLayer::handleSelfMsg(cMessage *msg) {
    switch( msg->kind() ){
    	case SEND_APPL_PACKET_TIMER:
			{
      	sendApplPacket();
			}
				break;
    	default:
    		EV << "Unkown selfmessage! -> delete, kind: "<<msg->kind() <<endl;
				delete msg;
    }
}

/**
 * This function creates a new appl. message and sends it down to
 * the routing layer
 **/
void GWApplLayer::sendApplPacket()
{
    ApplPkt *pkt = new ApplPkt("APPL_MESSAGE");

		// we don't set the destination: the destination MN will be chosen from the routing module 
    pkt->setSrcAddr( myApplAddr() );
    pkt->setLength( headerLength );
    pkt->setTimestamp();  //for statistical collection

		// EV << "Sending appl. packet!\n";
    sendDelayedDown( pkt,uniform(0,0.1) );

		if (simTime() < stopappltime)
		scheduleAt(simTime() + appltimer, delayTimer);  

		// update the counter
		numSent++;
		totalnumSent++;
		// update the GUI
    if (ev.isGUI()) {
				updateDisplay();
		}
}

void GWApplLayer::finish() 
{
    BasicApplLayer::finish();
    if(!delayTimer->isScheduled()) delete delayTimer;

 		recordScalar("#totalnumReceived", totalnumReceived);
		pktDelayStats.recordScalar("pk delay");
}

void GWApplLayer::updateDisplay()
{

		// display numSent and numReceived
    char buf[40];
    sprintf(buf, "sent: %ld rcvd: %ld", numSent, numReceived);
    parentModule()->displayString().setTagArg("t",0,buf);
	
		// display totalnumSent
		char totalbuf[20];
    sprintf(totalbuf, "totGWsent: %ld", totalnumSent);
    parentModule()->parentModule()->displayString().setTagArg("t",2,totalbuf);
   
		// display totalnumReceived
		char totalbuf2[20];
    sprintf(totalbuf2, "totGWreceived: %ld", totalnumReceived);
    parentModule()->parentModule()->displayString().setTagArg("t",1,totalbuf2);
		
}

