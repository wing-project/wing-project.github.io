/* -*- mode:c++ -*- ********************************************************
 * file:        MNRouting.h
 *
 * author:      Stefano Maurina
 *
 * copyright:   2008 University of Trento
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 ***************************************************************************
 * part of:     TBGMA Routing Protocol
 * description: Header file for the MNRouting Simple Module
 *
 ***************************************************************************/


#ifndef MNROUTING_H
#define MNROUTING_H

#include <omnetpp.h>

#include "BasicLayer.h"
#include "SimpleAddress.h"

#include <list>
#include "RANNPkt_m.h"
#include "RREPPkt_m.h"
#include "ApplPkt_m.h"
#include "NetwPkt_m.h"
#include "PROBEPkt_m.h"
#include "CHANGEPkt_m.h"
#include "GWREQPkt_m.h"
#include "GWREPPkt_m.h"

class MNRouting : public BasicLayer
{
protected:
		/** @brief cached variable of my MAC address */
		int myMACAddr;
		/** @brief cached variable of my networ address (not really used) */
    int myNetwAddr;
    /** @brief cached variable of the length of a RREP packet */
		int rrepheaderLength;
	  /** @brief cached variable of the length of a Unicast packet */
		int netwheaderLength;
		/** @brief cached variable of the lenght of a GWREQ packet */
		int gwreqheaderLength;
  	/** @brief cached variable of the lenght of a MAC packet */
		int macheaderLength;
  	/** @brief cached variable of the lenght of an application packet */
		int applheaderLength;
		/** @brief cached variable of the number of Gateways */
		int numGWs;  
		/** @brief cached variable of the timer: used during the route discovery in the cache routing table */
		double timer;  
		/** number of packets dropped */
		int numdropped;
		
		//ETX metric stuff
  	/** @brief cMessage pointer to be used as a self-message */
  	cMessage *etxTimer;
  	/** @brief cached variable of the time between a PROBE and the next */
		int delayetx;
  	/** @brief cached variable of the lenght of a PROBE packet */
		int etxheaderLength;
		/** @brief address of the default GW */
		int defaultGW;
		/** @brief last time we received a GWREP from a GW */
		simtime_t lastGWREPtime;
		/** @brief variable used to estimate the traffic to communicate to a GW during the GWREQ */		
		double appltimer;
		/** @brief estimated traffic to communicate to a GW during the GWREQ */		
		int estimrate;

		/** @brief vector which contains the arrival times of the probe packets from a neighbor */ 
		typedef std::vector< double > Beacon;

		/** @brief struct used for the etx computation */ 
		struct EtxEntry {
				int NodeMACAddr;
				Beacon beacon;
		};
			
		/** @brief map for etx computation */
		typedef std::list<EtxEntry> EtxTable;
		
		// We need an EtxMap for each Mesh Node
		EtxTable etxTable;

    /** @brief find a Neighbor in the etxTable based on its address */
    EtxTable::iterator findNeigh(int id)  {
	    EtxTable::iterator it;
        for(it = etxTable.begin(); it != etxTable.end(); ++it) {
            if(it->NodeMACAddr == id) break;
        }
        return it;
    }


    /** @brief struct used to represent a Routing Cache Entry */	
	  struct RoutingCacheEntry {
        int destGWMACAddr;
        unsigned int RANNSeqNumb;
        int potentialNextHopMacAddr;
        double ETX;
				simtime_t time;
    };

    /** @brief list used as a Routing Cache Table to keep the Routing Cache Entries */	
		typedef std::list<RoutingCacheEntry*> RoutingCacheTable;

    /** @brief struct used to represent a Gateway Routing Entry */	
    struct GWRoutingEntry {
        int destGWMACAddr;
        unsigned int RANNSeqNumb;
        int nextHopMacAddr;
        double ETX;
				
    };

    /** @brief list used as a GW Routing Table to keep the Gateway Routing Entries */	
		typedef std::list<GWRoutingEntry*> GWRoutingTable;

    /** @brief struct used to represent a Mesh Node Routing Entry */	
    struct MNRoutingEntry {
        int destMNMACAddr;
        int nextHopMacAddr;
    };

    /** @brief list used as a MN Routing Table to keep the Mesh Node Routing Entries */	
		typedef std::list<MNRoutingEntry*> MNRoutingTable;

		// We need a Cache Routing Table for each Mesh Node
		RoutingCacheTable cacheroutingtable;

		// We need a Gateway Routing Table for each Mesh Node
	  GWRoutingTable gwroutingtable;

		// We need a Mesh Routing Table for each Mesh Node
		MNRoutingTable mnroutingtable;

    /** @brief find a GW in the CRT based on its address */
    RoutingCacheTable::iterator findGWCRT(int id)  {
	    RoutingCacheTable::iterator it;
        for(it = cacheroutingtable.begin(); it != cacheroutingtable.end(); ++it) {
            if((*it)->destGWMACAddr == id) break;
        }
        return it;
    }

    /** @brief find a GW in the GRT based on its address */
    GWRoutingTable::iterator findGWGRT(int id)  {
	    GWRoutingTable::iterator it;
        for(it = gwroutingtable.begin(); it != gwroutingtable.end(); ++it) {
            if((*it)->destGWMACAddr == id) break;
        }
        return it;
    }

    /** @brief find a MN in the MNRT based on its address */
    MNRoutingTable::iterator findMN(int id)  {
	    MNRoutingTable::iterator it;
        for(it = mnroutingtable.begin(); it != mnroutingtable.end(); ++it) {
            if((*it)->destMNMACAddr == id) break;
        }
        return it;
    }

public:
    Module_Class_Members( MNRouting, BasicLayer, 0 );

    /** @brief Initialization of the module and some variables*/
    virtual void initialize(int);
  	virtual void finish();

    enum MNRouting_Self_Msg_Types{
			TIMER_MESSAGE,
			SEND_PROBE
    };

protected:
    
/** 
* @name Handle Messages
* @brief Functions to redefine by the programmer
*
* These are the functions provided to add own functionality to your
* modules. These functions are called whenever a self message or a
* data message from the upper or lower layer arrives respectively.
*
**/
/*@{*/
    
    /** @brief Handle messages from lower layer */
    virtual void handleLowerMsg(cMessage* msg);     // received messages from the mac layer

    /** @brief Handle self messages */ 
    virtual void handleSelfMsg(cMessage* msg);	

 		/** @brief Handle control messages from lower layer */
		virtual void handleLowerControl(cMessage* msg);  // control messages from the mac layer    
    /*@}*/

    /** @brief Handle messages from upper layer */
		virtual void handleUpperMsg(cMessage *msg);		// received messages from the appl. layer




    /** @brief decapsulate lower layer message */
    virtual cMessage* decapsMsg(NetwPkt*);  

    /** @brief Encapsulate higher layer packet */
    virtual NetwPkt* encapsMsg(ApplPkt*); 

    /** @brief forward a RREP packet received by another MN */
    void forwardRREP(RREPPkt* rrep);

		/** @brief this function forward an Appl. message toward a Gateway or a MN*/
		void forwardAppl(NetwPkt* pkt);

    /** @brief rebroadcast a RANN message */
    void rebroadcastRANN(RANNPkt* rann);

	  /** @brief check the Cache Routing Table and in case update it */
    void checkAndUpdateCRT(RANNPkt* rann);

		/** @brief update the Gateway Routing Table */
    void updateGWRT(int destGWAddress);

		/** @brief update the Mesh Node Routing Table */
    void updateMNRT(RREPPkt* rrep);

		/** @brief compute the global metric and return the GW address chosen */
		int globalMetric();

		/** @brief update the numer of messages dropped on the GUI */
		void updateDisplay();

		//ETX stuff 
		/** @brief feed the etxmap */
		void feedmapetx(PROBEPkt*);

  	/** @brief send a probe broadcast packet to the neighbors */
  	void sendPROBE();

  	/** @brief compute the etx metric upon receiving a RANN packet */
		double computeETX(int);

		//LDAB stuff
		void sendGW_REQ(int);
		void forwardCHANGE(CHANGEPkt*);
		void forwardGWREQ(GWREQPkt*);
		void forwardGWREP(GWREPPkt*);
};

#endif
